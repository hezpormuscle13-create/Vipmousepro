# Giữ Thẳng (Android + Shizuku)

Hít thẳng NHẸ khi kéo trên toàn hệ thống, tránh lệch. Không khóa cứng đường thẳng,
không vẽ đường xem trước, không cần Trợ năng. Cần Shizuku.

Build: đẩy lên GitHub, tab Actions sẽ tạo app-debug.apk ở mục Artifacts.
Upload dạng zip: đặt GiuThang.zip ở thư mục gốc repo + .github/workflows/build.yml.
