package com.giuthang.app;

interface IInputService {
    // Bắt buộc do Shizuku định nghĩa
    void destroy() = 16777114;

    // Tiêm một sự kiện chạm (action = MotionEvent.ACTION_*), toạ độ theo màn hình
    oneway void touch(int action, float x, float y) = 1;

    // Chạy lệnh shell với quyền shell (dùng để tự cấp quyền)
    String run(String command) = 2;
}
