package com.giuthang.app

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.graphics.drawable.Icon
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Toast

/**
 * Foreground service: một lớp phủ TRONG SUỐT toàn màn hình bắt thao tác kéo,
 * hít thẳng nhẹ rồi tiêm lại xuống ứng dụng bên dưới bằng Shizuku (thời gian thực).
 * Lớp phủ không vẽ gì cả.
 */
class OverlayService : Service() {

    companion object {
        @Volatile
        var running = false

        const val ACTION_STOP = "com.giuthang.app.STOP"
        private const val CHANNEL = "giuthang"
        private const val NOTIF_ID = 1
        private const val TOUCH_DELAY_MS = 25L

        fun start(c: Context) {
            c.startForegroundService(Intent(c, OverlayService::class.java))
        }

        fun stop(c: Context) {
            c.stopService(Intent(c, OverlayService::class.java))
        }
    }

    private lateinit var wm: WindowManager
    private lateinit var lp: WindowManager.LayoutParams
    private var view: TouchView? = null
    private val main = Handler(Looper.getMainLooper())

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        startAsForeground()
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (view == null) addOverlay()
        ShizukuBridge.bind()
        running = true
        return START_STICKY
    }

    override fun onDestroy() {
        running = false
        view?.release()
        try {
            view?.let { wm.removeView(it) }
        } catch (_: Throwable) {
        }
        view = null
        main.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Giữ thẳng", NotificationManager.IMPORTANCE_LOW)
        )
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val stopPi = PendingIntent.getService(
            this, 1,
            Intent(this, OverlayService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("Giữ thẳng đang bật")
            .setContentText("Bấm Tắt để dừng.")
            .setContentIntent(open)
            .addAction(
                Notification.Action.Builder(
                    Icon.createWithResource(this, R.drawable.ic_stat), "Tắt", stopPi
                ).build()
            )
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    private fun addOverlay() {
        lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            // Android 12+: độ mờ cửa sổ phải <= 0.8 thì cảm ứng mới đi xuyên xuống app bên dưới được
            alpha = 0.5f
        }
        val v = TouchView(this)
        wm.addView(v, lp)
        view = v
    }

    private fun setTouchable(touchable: Boolean) {
        val v = view ?: return
        lp.flags = if (touchable) {
            lp.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
        } else {
            lp.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        }
        try {
            wm.updateViewLayout(v, lp)
        } catch (_: Throwable) {
        }
    }

    @SuppressLint("ViewConstructor")
    private inner class TouchView(c: Context) : View(c) {
        private val st = Straightener()
        private var pointerId = -1
        private var injecting = false
        private var ready = false
        private var lastX = 0f
        private var lastY = 0f
        private val queue = ArrayList<FloatArray>()

        private val flush = Runnable {
            ready = true
            val q = ArrayList(queue)
            queue.clear()
            for (o in q) sendNow(o[0].toInt(), o[1], o[2])
        }
        private val restore = Runnable { setTouchable(true) }

        // ---------- nhận cảm ứng thật ----------
        @SuppressLint("ClickableViewAccessibility")
        override fun onTouchEvent(e: MotionEvent): Boolean {
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    pointerId = e.getPointerId(0)
                    down(px(e, 0), py(e, 0))
                }
                MotionEvent.ACTION_MOVE -> {
                    val i = e.findPointerIndex(pointerId)
                    if (i >= 0) {
                        for (h in 0 until e.historySize) move(hx(e, i, h), hy(e, i, h))
                        move(px(e, i), py(e, i))
                    }
                }
                MotionEvent.ACTION_POINTER_UP -> {
                    if (e.getPointerId(e.actionIndex) == pointerId) up(false)
                }
                MotionEvent.ACTION_UP -> {
                    val i = e.findPointerIndex(pointerId)
                    if (i >= 0) move(px(e, i), py(e, i))
                    up(false)
                }
                MotionEvent.ACTION_CANCEL -> up(true)
            }
            return true
        }

        private fun ox(e: MotionEvent) = e.rawX - e.getX(0)
        private fun oy(e: MotionEvent) = e.rawY - e.getY(0)
        private fun px(e: MotionEvent, i: Int) = e.getX(i) + ox(e)
        private fun py(e: MotionEvent, i: Int) = e.getY(i) + oy(e)
        private fun hx(e: MotionEvent, i: Int, h: Int) = e.getHistoricalX(i, h) + ox(e)
        private fun hy(e: MotionEvent, i: Int, h: Int) = e.getHistoricalY(i, h) + oy(e)

        // ---------- xử lý nét ----------
        private fun down(x: Float, y: Float) {
            if (!ShizukuBridge.ready()) {
                // Mất Shizuku => tự tắt để không chặn cảm ứng của điện thoại
                pointerId = -1
                main.post {
                    Toast.makeText(
                        applicationContext,
                        "Mất kết nối Shizuku, đã tắt Giữ thẳng",
                        Toast.LENGTH_LONG
                    ).show()
                    stopSelf()
                }
                return
            }
            st.begin(x, y, Prefs.load(context))
            lastX = x
            lastY = y
            if (injecting) sendNow(MotionEvent.ACTION_UP, lastX, lastY) // dọn nét trước nếu còn treo
            injecting = true
            ready = false
            queue.clear()
            main.removeCallbacks(restore)
            main.removeCallbacks(flush)
            setTouchable(false) // để cảm ứng tiêm xuống đi xuyên qua lớp phủ
            send(MotionEvent.ACTION_DOWN, x, y)
            main.postDelayed(flush, TOUCH_DELAY_MS)
        }

        private fun move(x: Float, y: Float) {
            if (pointerId == -1) return
            val o = st.move(x, y)
            lastX = o[0]
            lastY = o[1]
            send(MotionEvent.ACTION_MOVE, o[0], o[1])
        }

        private fun up(cancel: Boolean) {
            if (pointerId == -1) return
            pointerId = -1
            val f = st.finish()
            if (f[0] != lastX || f[1] != lastY) send(MotionEvent.ACTION_MOVE, f[0], f[1])
            send(if (cancel) MotionEvent.ACTION_CANCEL else MotionEvent.ACTION_UP, f[0], f[1])
            injecting = false
            main.postDelayed(restore, 40)
        }

        // ---------- Shizuku ----------
        private fun send(action: Int, x: Float, y: Float) {
            if (!ready) queue.add(floatArrayOf(action.toFloat(), x, y)) else sendNow(action, x, y)
        }

        private fun sendNow(action: Int, x: Float, y: Float) {
            try {
                ShizukuBridge.service?.touch(action, x, y)
            } catch (_: Throwable) {
            }
        }

        fun release() {
            main.removeCallbacks(flush)
            main.removeCallbacks(restore)
            if (injecting) {
                sendNow(MotionEvent.ACTION_UP, lastX, lastY)
                injecting = false
            }
        }
    }
}
