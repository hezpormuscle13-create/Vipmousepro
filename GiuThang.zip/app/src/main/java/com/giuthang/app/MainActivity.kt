package com.giuthang.app

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import rikka.shizuku.Shizuku

private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

class MainActivity : Activity() {

    private lateinit var draw: DrawView
    private lateinit var toggle: Button
    private lateinit var status: TextView
    private val modeButtons = ArrayList<Button>()
    private val main = Handler(Looper.getMainLooper())

    private val ticker = object : Runnable {
        override fun run() {
            ShizukuBridge.bind()
            refresh()
            main.postDelayed(this, 1000)
        }
    }

    private val binderListener = Shizuku.OnBinderReceivedListener {
        runOnUiThread { ShizukuBridge.bind(); refresh() }
    }
    private val deadListener = Shizuku.OnBinderDeadListener {
        runOnUiThread { refresh() }
    }
    private val permListener = Shizuku.OnRequestPermissionResultListener { _, _ ->
        runOnUiThread { ShizukuBridge.bind(); refresh() }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun round(color: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(14).toFloat()
    }

    private fun button(text: String, color: Int, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = text
        b.isAllCaps = false
        b.setTextColor(Color.WHITE)
        b.textSize = 15f
        b.minHeight = dp(52)
        b.background = round(color)
        b.setOnClickListener { onClick() }
        return b
    }

    private fun label(text: String): TextView {
        val t = TextView(this)
        t.text = text
        t.setTextColor(Color.WHITE)
        t.textSize = 16f
        return t
    }

    private fun LinearLayout.addv(v: View, top: Int = 12) {
        addView(v, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(top) })
    }

    private fun slider(parent: LinearLayout, title: String, key: String, lo: Int, hi: Int, init: Int, unit: String) {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        val name = label(title)
        val value = TextView(this)
        value.setTextColor(0xFFBBBBBB.toInt())
        value.textSize = 16f
        value.gravity = Gravity.END
        value.text = "$init$unit"
        val sb = SeekBar(this)
        sb.max = hi - lo
        sb.progress = init - lo
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                val v = p + lo
                value.text = "$v$unit"
                Prefs.putInt(this@MainActivity, key, v)
            }

            override fun onStartTrackingTouch(s: SeekBar?) {
                parent.requestDisallowInterceptTouchEvent(true)
            }

            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        row.addView(name, LinearLayout.LayoutParams(dp(130), WRAP))
        row.addView(sb, LinearLayout.LayoutParams(0, WRAP, 1f))
        row.addView(value, LinearLayout.LayoutParams(dp(56), WRAP))
        parent.addv(row, 10)
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val cfg = Prefs.load(this)

        val root = ScrollView(this)
        root.setBackgroundColor(0xFF121212.toInt())
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        root.addView(col, ViewGroup.LayoutParams(MATCH, WRAP))

        draw = DrawView(this)
        col.addView(draw, LinearLayout.LayoutParams(MATCH, (resources.displayMetrics.heightPixels * 0.40f).toInt()))

        val panel = LinearLayout(this)
        panel.orientation = LinearLayout.VERTICAL
        panel.setPadding(dp(16), dp(16), dp(16), dp(32))
        col.addView(panel, LinearLayout.LayoutParams(MATCH, WRAP))

        toggle = button("", 0xFF555555.toInt()) { toggleOverlay() }
        toggle.textSize = 18f
        toggle.setTypeface(toggle.typeface, Typeface.BOLD)
        panel.addv(toggle, 0)

        // Kiểu: Tự động / Ngang / Dọc
        val modeRow = LinearLayout(this)
        modeRow.orientation = LinearLayout.HORIZONTAL
        modeRow.gravity = Gravity.CENTER_VERTICAL
        modeRow.addView(label("Kiểu"), LinearLayout.LayoutParams(WRAP, WRAP))
        val names = listOf("Tự động", "Ngang", "Dọc")
        names.forEachIndexed { i, n ->
            val b = button(n, 0xFF2A2A2A.toInt()) {
                Prefs.putInt(this@MainActivity, "mode", i)
                paintModes()
            }
            modeButtons.add(b)
            modeRow.addView(b, LinearLayout.LayoutParams(0, WRAP, 1f).apply {
                setMargins(dp(6), 0, 0, 0)
            })
        }
        panel.addv(modeRow, 12)

        slider(panel, "Độ mượt", "smooth", 0, 100, cfg.smooth, "")
        slider(panel, "Độ hít thẳng", "assist", 0, 100, cfg.assist, "%")
        slider(panel, "Góc hút", "angle", 3, 40, cfg.angle, "°")
        slider(panel, "Độ dày nét", "width", 1, 20, cfg.width, "")

        panel.addv(button("Xóa hết", 0xFFD32F2F.toInt()) { draw.clear() }, 14)

        // ---- Quyền & Shizuku ----
        val title = label("Quyền cần cấp")
        title.setTypeface(title.typeface, Typeface.BOLD)
        panel.addv(title, 28)

        status = TextView(this)
        status.setTextColor(0xFFCCCCCC.toInt())
        status.textSize = 14f
        panel.addv(status, 8)

        panel.addv(button("1. Mở Shizuku", 0xFF37474F.toInt()) {
            val i = packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")
            if (i != null) startActivity(i) else toast("Chưa cài ứng dụng Shizuku")
        }, 10)
        panel.addv(button("2. Cấp quyền Shizuku cho app này", 0xFF1565C0.toInt()) {
            if (!ShizukuBridge.isAvailable()) {
                toast("Shizuku chưa chạy. Hãy mở Shizuku và bấm Start trước.")
            } else if (ShizukuBridge.hasPermission()) {
                ShizukuBridge.bind()
                toast("Đã có quyền Shizuku")
            } else {
                ShizukuBridge.requestPermission()
            }
        })
        panel.addv(button("3. Tự cấp các quyền còn lại bằng Shizuku", 0xFF1565C0.toInt()) { autoGrant() })
        panel.addv(button("Cấp quyền hiển thị trên ứng dụng khác (thủ công)", 0xFF37474F.toInt()) {
            openOverlaySettings()
        })
        panel.addv(button("Bỏ tối ưu pin (thủ công)", 0xFF37474F.toInt()) {
            try {
                startActivity(
                    Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))
                )
            } catch (_: Throwable) {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            }
        })

        setContentView(root)

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }

        Shizuku.addBinderReceivedListenerSticky(binderListener)
        Shizuku.addBinderDeadListener(deadListener)
        Shizuku.addRequestPermissionResultListener(permListener)
    }

    override fun onResume() {
        super.onResume()
        main.post(ticker)
    }

    override fun onPause() {
        main.removeCallbacks(ticker)
        super.onPause()
    }

    override fun onDestroy() {
        Shizuku.removeBinderReceivedListener(binderListener)
        Shizuku.removeBinderDeadListener(deadListener)
        Shizuku.removeRequestPermissionResultListener(permListener)
        super.onDestroy()
    }

    private fun openOverlaySettings() {
        startActivity(
            Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
        )
    }

    private fun toggleOverlay() {
        if (OverlayService.running) {
            OverlayService.stop(this)
            main.postDelayed({ refresh() }, 300)
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            toast("Hãy cấp quyền hiển thị trên ứng dụng khác trước.")
            openOverlaySettings()
            return
        }
        if (!ShizukuBridge.ready()) {
            toast("Chưa kết nối Shizuku. Mở Shizuku (Start) rồi cấp quyền cho app ở bước 2.")
            return
        }
        OverlayService.start(this)
        main.postDelayed({ refresh() }, 400)
    }

    private fun paintModes() {
        val m = Prefs.load(this).mode
        modeButtons.forEachIndexed { i, b ->
            b.background = round(if (i == m) 0xFF2E7D32.toInt() else 0xFF2A2A2A.toInt())
        }
    }

    private fun refresh() {
        val on = OverlayService.running
        toggle.text = "Giữ thẳng: " + if (on) "BẬT" else "TẮT"
        toggle.background = round(if (on) 0xFF2E7D32.toInt() else 0xFF555555.toInt())
        paintModes()

        fun mark(b: Boolean) = if (b) "✓" else "✗"
        status.text = buildString {
            append("${mark(Settings.canDrawOverlays(this@MainActivity))} Hiển thị trên ứng dụng khác\n")
            append("${mark(ShizukuBridge.isAvailable())} Shizuku đang chạy\n")
            append("${mark(ShizukuBridge.hasPermission())} Đã cấp quyền Shizuku\n")
            append("${mark(ShizukuBridge.ready())} Dịch vụ Shizuku đã kết nối")
        }
    }

    private fun autoGrant() {
        if (!ShizukuBridge.ready()) {
            toast("Cần mở Shizuku (Start) và cấp quyền Shizuku cho app trước (bước 2).")
            return
        }
        val pkg = packageName
        val steps = listOf(
            "Hiển thị trên ứng dụng khác" to "appops set $pkg SYSTEM_ALERT_WINDOW allow",
            "Thông báo" to "pm grant $pkg android.permission.POST_NOTIFICATIONS",
            "Bỏ tối ưu pin" to "dumpsys deviceidle whitelist +$pkg"
        )
        Thread {
            val sb = StringBuilder()
            for ((name, cmd) in steps) {
                val r = ShizukuBridge.run(cmd)
                sb.append("• ").append(name).append(": ")
                    .append(if (r.isBlank()) "OK" else r.take(120)).append("\n")
            }
            runOnUiThread {
                AlertDialog.Builder(this)
                    .setTitle("Kết quả")
                    .setMessage(sb.toString())
                    .setPositiveButton("OK", null)
                    .show()
                refresh()
            }
        }.start()
    }
}
