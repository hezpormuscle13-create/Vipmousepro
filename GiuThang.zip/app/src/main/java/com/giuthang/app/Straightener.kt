package com.giuthang.app

import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * Hít thẳng NHẸ, không khóa cứng.
 *
 * Mỗi bước di chuyển được tách thành thành phần "dọc theo trục gần nhất" và
 * thành phần "lệch ngang". Thành phần lệch ngang bị giảm bớt theo độ hít thẳng,
 * nên nét dần thẳng lại và không bị trôi lệch, nhưng khi bạn chủ ý cua/quẹo thì
 * hướng thật của ngón tay lệch khỏi trục, lực hít tự giảm về 0 và nét đi tự do.
 *
 * Độ mượt chỉ làm trơn vị trí đầu ra để bớt rung.
 */
class Straightener {
    private companion object {
        const val WARMUP = 16f       // px đầu tiên giữ nguyên, không can thiệp
        const val MAX_OFFSET = 60f   // lệch tối đa giữa điểm đầu ra và ngón tay (px)
        val AUTO_AXES = floatArrayOf(0f, 45f, 90f, 135f)
        val AXIS_H = floatArrayOf(0f)
        val AXIS_V = floatArrayOf(90f)
    }

    private var cfg = Config(Prefs.MODE_AUTO, 35, 45, 15, 4)
    private var rawX = 0f
    private var rawY = 0f
    private var hx = 0f
    private var hy = 0f
    private var hasHeading = false
    private var travelled = 0f
    private var tgtX = 0f
    private var tgtY = 0f
    private var outX = 0f
    private var outY = 0f

    fun begin(x: Float, y: Float, c: Config) {
        cfg = c
        rawX = x; rawY = y
        tgtX = x; tgtY = y
        outX = x; outY = y
        hx = 0f; hy = 0f
        hasHeading = false
        travelled = 0f
    }

    /** Trả về điểm đầu ra đã hít thẳng nhẹ + làm mượt. */
    fun move(x: Float, y: Float): FloatArray {
        val dx = x - rawX
        val dy = y - rawY
        rawX = x
        rawY = y

        var ax = dx
        var ay = dy
        val len = hypot(dx, dy)
        if (len > 0.3f) {
            if (!hasHeading) {
                hx = dx; hy = dy; hasHeading = true
            } else {
                hx += (dx - hx) * 0.2f
                hy += (dy - hy) * 0.2f
            }
            travelled += len
            if (travelled > WARMUP) {
                val w = pull()
                if (w > 0f) {
                    val axis = bestAxis()
                    val rad = Math.toRadians(axis.toDouble())
                    val gx = cos(rad).toFloat()
                    val gy = sin(rad).toFloat()
                    val along = dx * gx + dy * gy
                    ax = dx - w * (dx - along * gx)
                    ay = dy - w * (dy - along * gy)
                }
            }
        }

        tgtX += ax
        tgtY += ay

        // Không để điểm đầu ra lệch xa ngón tay quá MAX_OFFSET
        val ox = tgtX - x
        val oy = tgtY - y
        val dist = hypot(ox, oy)
        if (dist > MAX_OFFSET) {
            val s = MAX_OFFSET / dist
            tgtX = x + ox * s
            tgtY = y + oy * s
        }

        val a = 1f - 0.9f * cfg.smooth / 100f
        outX += (tgtX - outX) * a
        outY += (tgtY - outY) * a
        return floatArrayOf(outX, outY)
    }

    /** Điểm cuối khi nhả tay (không bị trễ do làm mượt). */
    fun finish(): FloatArray {
        outX = tgtX
        outY = tgtY
        return floatArrayOf(outX, outY)
    }

    private fun axes(): FloatArray = when (cfg.mode) {
        Prefs.MODE_H -> AXIS_H
        Prefs.MODE_V -> AXIS_V
        else -> AUTO_AXES
    }

    /** Góc hút: chế độ Ngang/Dọc rộng gấp đôi vì bạn đã nói rõ ý định. */
    private fun tolerance(): Float {
        val t = max(cfg.angle.toFloat(), 1f)
        return if (cfg.mode == Prefs.MODE_AUTO) t else min(t * 2f, 60f)
    }

    private fun theta(): Float {
        var t = Math.toDegrees(atan2(hy, hx).toDouble()).toFloat()
        t = ((t % 180f) + 180f) % 180f
        return t
    }

    private fun diffTo(axis: Float, t: Float): Float {
        val d = abs(t - axis)
        return min(d, 180f - d)
    }

    private fun bestAxis(): Float {
        val t = theta()
        var best = 0f
        var bd = Float.MAX_VALUE
        for (a in axes()) {
            val d = diffTo(a, t)
            if (d < bd) { bd = d; best = a }
        }
        return best
    }

    /** Lực hít 0..1: mạnh khi hướng gần trục, về 0 khi lệch quá góc hút. */
    private fun pull(): Float {
        if (hypot(hx, hy) < 0.3f) return 0f
        val t = theta()
        var bd = Float.MAX_VALUE
        for (a in axes()) bd = min(bd, diffTo(a, t))
        val tol = tolerance()
        if (bd >= tol) return 0f
        val closeness = 1f - bd / tol
        return (cfg.assist / 100f) * closeness
    }
}
