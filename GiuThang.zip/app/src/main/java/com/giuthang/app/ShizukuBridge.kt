package com.giuthang.app

import android.content.ComponentName
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.IBinder
import android.os.SystemClock
import rikka.shizuku.Shizuku

object ShizukuBridge {
    private const val REQUEST_CODE = 4242

    @Volatile
    var service: IInputService? = null

    @Volatile
    private var binding = false
    private var bindTime = 0L

    private val conn = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            binding = false
            service = if (binder != null && binder.pingBinder()) IInputService.Stub.asInterface(binder) else null
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            service = null
            binding = false
        }
    }

    private val args by lazy {
        Shizuku.UserServiceArgs(ComponentName("com.giuthang.app", InputService::class.java.name))
            .daemon(false)
            .processNameSuffix("input")
            .debuggable(false)
            .version(1)
    }

    /** Dịch vụ tiêm cảm ứng đã kết nối và còn sống. */
    fun ready(): Boolean = try {
        service?.asBinder()?.pingBinder() == true
    } catch (_: Throwable) {
        false
    }

    fun isAvailable(): Boolean = try {
        Shizuku.pingBinder()
    } catch (_: Throwable) {
        false
    }

    fun hasPermission(): Boolean = try {
        isAvailable() && !Shizuku.isPreV11() &&
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (_: Throwable) {
        false
    }

    fun requestPermission() {
        try {
            if (isAvailable() && !Shizuku.isPreV11()) Shizuku.requestPermission(REQUEST_CODE)
        } catch (_: Throwable) {
        }
    }

    fun bind() {
        if (ready() || !hasPermission()) return
        val now = SystemClock.uptimeMillis()
        if (binding && now - bindTime < 5000) return
        binding = true
        bindTime = now
        try {
            Shizuku.bindUserService(args, conn)
        } catch (_: Throwable) {
            binding = false
        }
    }

    fun run(cmd: String): String = try {
        service?.run(cmd) ?: "Chưa kết nối dịch vụ Shizuku"
    } catch (t: Throwable) {
        "Lỗi: ${t.message}"
    }
}
