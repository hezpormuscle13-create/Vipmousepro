package com.giuthang.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.view.MotionEvent
import android.view.View

/** Khung vẽ thử ngay trong app để chỉnh các thanh trượt. */
class DrawView(context: Context) : View(context) {
    private class Stroke(val path: Path, val width: Float)

    private val strokes = ArrayList<Stroke>()
    private var cur: Stroke? = null
    private val st = Straightener()
    private val density = resources.displayMetrics.density
    private val step = 48f * density

    private val ink = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val grid = Paint().apply {
        color = 0xFF2A2A2A.toInt()
        strokeWidth = 2f
    }

    fun clear() {
        strokes.clear()
        cur = null
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        canvas.drawColor(0xFF1A1A1A.toInt())
        var x = 0f
        while (x < width) {
            canvas.drawLine(x, 0f, x, height.toFloat(), grid)
            x += step
        }
        var y = 0f
        while (y < height) {
            canvas.drawLine(0f, y, width.toFloat(), y, grid)
            y += step
        }
        for (s in strokes) {
            ink.strokeWidth = s.width
            canvas.drawPath(s.path, ink)
        }
        cur?.let {
            ink.strokeWidth = it.width
            canvas.drawPath(it.path, ink)
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                val cfg = Prefs.load(context)
                st.begin(e.x, e.y, cfg)
                cur = Stroke(Path().apply { moveTo(e.x, e.y) }, cfg.width * density)
            }
            MotionEvent.ACTION_MOVE -> {
                for (h in 0 until e.historySize) add(e.getHistoricalX(h), e.getHistoricalY(h))
                add(e.x, e.y)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                val s = cur
                if (s != null) {
                    val f = st.finish()
                    s.path.lineTo(f[0], f[1])
                    strokes.add(s)
                    cur = null
                }
            }
        }
        invalidate()
        return true
    }

    private fun add(x: Float, y: Float) {
        val o = st.move(x, y)
        cur?.path?.lineTo(o[0], o[1])
    }
}
