package com.giuthang.app

import android.content.Context

/**
 * mode: Tự động / Ngang / Dọc
 * smooth: độ mượt 0..100
 * assist: độ hít thẳng 0..100 (%)
 * angle: góc hút (độ) - chỉ hít khi hướng kéo lệch trục không quá góc này
 * width: độ dày nét (chỉ dùng cho khung vẽ thử)
 */
data class Config(val mode: Int, val smooth: Int, val assist: Int, val angle: Int, val width: Int)

object Prefs {
    const val MODE_AUTO = 0
    const val MODE_H = 1
    const val MODE_V = 2

    private fun sp(c: Context) = c.getSharedPreferences("giuthang", Context.MODE_PRIVATE)

    fun load(c: Context): Config {
        val p = sp(c)
        return Config(
            mode = p.getInt("mode", MODE_AUTO),
            smooth = p.getInt("smooth", 35),
            assist = p.getInt("assist", 45),
            angle = p.getInt("angle", 15),
            width = p.getInt("width", 4)
        )
    }

    fun putInt(c: Context, key: String, value: Int) {
        sp(c).edit().putInt(key, value).apply()
    }
}
