package com.giuthang.app

import android.os.IBinder
import android.os.SystemClock
import android.util.Log
import android.view.InputDevice
import android.view.InputEvent
import android.view.MotionEvent
import java.lang.reflect.Method
import kotlin.system.exitProcess

/**
 * Chạy trong tiến trình shell do Shizuku khởi tạo (uid 2000),
 * nên có quyền INJECT_EVENTS để tiêm cảm ứng vào ứng dụng bên dưới.
 */
class InputService : IInputService.Stub() {
    private var manager: Any? = null
    private var injectMethod: Method? = null
    private var downTime = 0L

    init {
        try {
            val sm = Class.forName("android.os.ServiceManager")
            val binder = sm.getMethod("getService", String::class.java).invoke(null, "input") as IBinder
            val stub = Class.forName("android.hardware.input.IInputManager\$Stub")
            manager = stub.getMethod("asInterface", IBinder::class.java).invoke(null, binder)
            injectMethod = manager!!.javaClass.getMethod(
                "injectInputEvent",
                InputEvent::class.java,
                Int::class.javaPrimitiveType
            )
        } catch (t: Throwable) {
            Log.e("GiuThang", "Khong lay duoc IInputManager", t)
        }
    }

    override fun destroy() {
        exitProcess(0)
    }

    override fun touch(action: Int, x: Float, y: Float) {
        val m = injectMethod ?: return
        val now = SystemClock.uptimeMillis()
        if (action == MotionEvent.ACTION_DOWN) downTime = now
        val ev = MotionEvent.obtain(downTime, now, action, x, y, 1.0f, 1.0f, 0, 1.0f, 1.0f, 0, 0)
        ev.source = InputDevice.SOURCE_TOUCHSCREEN
        try {
            m.invoke(manager, ev, 0) // 0 = INJECT_INPUT_EVENT_MODE_ASYNC
        } catch (t: Throwable) {
            Log.e("GiuThang", "inject loi", t)
        } finally {
            ev.recycle()
        }
    }

    override fun run(command: String?): String {
        if (command == null) return ""
        return try {
            val p = ProcessBuilder("sh", "-c", command).redirectErrorStream(true).start()
            val out = p.inputStream.bufferedReader().readText()
            p.waitFor()
            out.trim()
        } catch (t: Throwable) {
            "ERR: ${t.message}"
        }
    }
}
